local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local ws = workspace
local lp = Players.LocalPlayer
-- executor globals, resolved through the environment: a missing one becomes a
-- clean false instead of a nil call, and the linter can see they are looked up
-- rather than assumed
local ENV = getfenv(1)
local keyPressFn = ENV.keypress
local keyReleaseFn = ENV.keyrelease

local UMT = _G.UMT or {}
_G.UMT = UMT

UMT.cfg = UMT.cfg or {
	keys = true,
	plotKey = "P",
	vehicleKey = "V",
	height = 6,
	cooldownS = 0.35,
}
-- migrations, so a table left by an older build cannot read as "off"
if UMT.cfg.lean == nil then UMT.cfg.lean = true end
if UMT.cfg.debug == nil then UMT.cfg.debug = false end
if UMT.cfg.keys == nil then UMT.cfg.keys = UMT.cfg.enabled ~= false end
if UMT.cfg.autoSell == nil then UMT.cfg.autoSell = false end
if UMT.cfg.sellMin == nil then UMT.cfg.sellMin = 1 end
if UMT.cfg.sellReturn == nil then UMT.cfg.sellReturn = true end
if UMT.cfg.sellRange == nil then UMT.cfg.sellRange = 14 end

-- RETIRING OLD HANDLERS. Builds v1 and v2 gated their key handler on
-- cfg.enabled and printed unconditionally, and there is no way to enumerate
-- InputBegan connections to disconnect them - which is why one press could
-- print twice. cfg.enabled is therefore pinned to false forever: those old
-- handlers read it and return before they do anything. This build keys off
-- cfg.keys instead, so its own keys keep working.

-- THE CONSOLE IS FOR PROBLEMS. A successful teleport prints nothing unless
-- the Debug log toggle is on; anything that failed still prints, because that
-- is the only way to find out why a key did not move you.
local function debugOn() return UMT.cfg.debug == true end
local function log(msg) if debugOn() then print("[UMT] " .. msg) end end
local function alert(msg) print("[UMT] " .. msg) end

UMT.cfg.enabled = false

UMT.build = "v5.1 2026-10-19 auto-sell"
UMT.cache = UMT.cache or { plot = nil, vehicle = nil }
UMT.lastTp = 0

-- Every loaded chunk takes a new generation. A handler left behind by an older
-- chunk (rerun, or a test that re-installed one) sees a stale id and returns,
-- so one keypress can never teleport twice or print the same line twice.
UMT.gen = (UMT.gen or 0) + 1
local myGen = UMT.gen

UMT.setDebug = function(on)
	UMT.cfg.debug = on and true or false
	if UMT.cfg.debug then alert("debug log ON") else alert("debug log OFF") end
end

--=========================== FINDING MY PLOT ===============================
local function plotAttribute()
	local plots = ws:FindFirstChild("Plots")
	if not plots then return nil end
	for _, m in ipairs(plots:GetChildren()) do
		local ok, oid = pcall(function() return m:GetAttribute("OwnerId") end)
		if ok and oid ~= nil and tonumber(oid) == lp.UserId then return m end
	end
	return nil
end

-- our factory node, however the game nested it this session
local function myFactory()
	local fg = ws:FindFirstChild("FactoryGridItemsClient")
	if not fg then return nil end
	local a = fg:FindFirstChild(lp.Name)
	if not a then return nil end
	return a:FindFirstChild(lp.Name) or a
end

-- the one part that is always on our plot and is cheap to read
local function factoryAnchor()
	local node = myFactory()
	if not node then return nil end
	local spawner = node:FindFirstChild("VehicleSpawner")
	if spawner then
		local c = spawner:FindFirstChild("Centre")
		if c then return c.Position end
	end
	-- no VehicleSpawner yet (nothing built): average the node's parts once.
	-- 4k parts is a one-off GetDescendants, never a per-tick cost.
	local sum, n = Vector3.new(0, 0, 0), 0
	for _, d in ipairs(node:GetDescendants()) do
		if d.ClassName == "Part" then
			sum = sum + d.Position
			n = n + 1
		end
	end
	if n == 0 then return nil end
	return sum / n
end

local function plotFromGeometry()
	local plots = ws:FindFirstChild("Plots")
	local anchor = factoryAnchor()
	if not (plots and anchor) then return nil end
	local best, bestD = nil, math.huge
	for _, m in ipairs(plots:GetChildren()) do
		local c = m:FindFirstChild("Centre")
		if c then
			local d = (c.Position - anchor).Magnitude
			if d < bestD then best, bestD = m, d end
		end
	end
	return best, bestD
end

local function findPlot()
	local byAttr = plotAttribute()
	if byAttr then return byAttr, "attribute" end
	local byGeo, d = plotFromGeometry()
	if byGeo then return byGeo, string.format("geometry, anchor %.0f studs from Centre", d or 0) end
	return nil
end

--=========================== FINDING MY VEHICLE ============================
local function findVehicle()
	local folder = ws:FindFirstChild("Vehicles")
	if not folder then return nil end
	for _, v in ipairs(folder:GetChildren()) do
		local ok, oid = pcall(function() return v:GetAttribute("OwnerId") end)
		if ok and oid ~= nil and tonumber(oid) == lp.UserId then return v end
	end
	for _, v in ipairs(folder:GetChildren()) do
		local ok, did = pcall(function() return v:GetAttribute("DriverId") end)
		if ok and did ~= nil and tonumber(did) == lp.UserId then return v end
	end
	return nil
end

local function vehicleAnchor(v)
	if not v then return nil end
	local b = v:FindFirstChild("Base") or v:FindFirstChild("MassCenter")
	if b then return b.Position end
	for _, d in ipairs(v:GetDescendants()) do
		if d.ClassName == "Part" and d.Name ~= "Hitbox" then return d.Position end
	end
	return nil
end

--=========================== TELEPORT =====================================
local function characterParts()
	local char = lp.Character
	if not char then return nil end
	local hrp = char:FindFirstChild("HumanoidRootPart")
	local hum = char:FindFirstChildOfClass("Humanoid")
	if not hrp then return nil end
	return char, hrp, hum
end

local function teleport(pos, label)
	local _, hrp, hum = characterParts()
	if not hrp then
		alert("no character (respawning?) - " .. label .. " skipped")
		return false
	end
	if hum and hum.Sit then
		-- a seated character ignores root CFrame writes: the weld wins
		alert("you are seated in a vehicle - jump out first, then " .. label)
		return false, "seated"
	end
	local t = pos + Vector3.new(0, UMT.cfg.height, 0)
	hrp.CFrame = CFrame.new(t.X, t.Y, t.Z)
	UMT.tpCount = (UMT.tpCount or 0) + 1
	log(string.format("%s -> (%.1f, %.1f, %.1f)", label, t.X, t.Y, t.Z))
	return true
end

--=========================== ACTIONS ======================================
local function goPlot(silent)
	local plot, how = UMT.cache.plot, "cache"
	if not plot or not plot.Parent then
		plot, how = findPlot()
		UMT.cache.plot = plot
	end
	if not plot then
		alert("no plot found: workspace.Plots or your factory grid is not replicated yet - wait for the base to load")
		return false
	end
	local bp = plot:FindFirstChild("BuildPlot") or plot:FindFirstChild("Centre")
	if not bp then
		alert("plot " .. plot.Name .. " has no BuildPlot part")
		return false
	end
	local ok = teleport(bp.Position, "plot " .. plot.Name .. " (" .. tostring(how) .. ")")
	if ok and not silent then log("on your plot now - BuildPlot at " .. tostring(bp.Position)) end
	return ok
end

local function goVehicle(silent)
	local v = UMT.cache.vehicle
	if not v or not v.Parent then
		v = findVehicle()
		UMT.cache.vehicle = v
	end
	if not v then
		alert("no vehicle found: nothing in workspace.Vehicles carries OwnerId " .. tostring(lp.UserId) .. " - unlock/spawn one at the VehicleSpawner")
		return false
	end
	local pos = vehicleAnchor(v)
	if not pos then
		alert("vehicle " .. v.Name .. " has no Base/MassCenter part")
		return false
	end
	local ok = teleport(pos, "vehicle " .. v.Name)
	if ok and not silent then log("next to your " .. v.Name .. " now") end
	return ok
end

--=========================== AUTO SELL ====================================
-- There is no Sell remote in this game and the money chute does nothing when
-- you stand on it (measured: 45 chunks carried, money unchanged). The sell
-- path is the unloader's own ProximityPrompt - "Add Items", E - which empties
-- OrePackCargo on the server: measured 45 chunks in the pack, one E press, 1
-- left. The pack is visible client-side as the children of
-- Workspace.<you>.OrePackCargo, so the count is free to read.
local function oreCount()
	local ch = lp.Character
	local op = ch and ch:FindFirstChild("OrePackCargo")
	if not op then return 0 end
	return #op:GetChildren()
end

local function cargoVolume()
	local srv = ws:FindFirstChild("FactoryGridItemsServer")
	local mine = srv and srv:FindFirstChild(lp.Name)
	return mine and mine:FindFirstChild("CargoVolume")
end

local function tapE()
	if type(keyPressFn) ~= "function" then
		alert("keypress() is not available in this executor - auto-sell cannot press E")
		return false
	end
	local ok = pcall(keyPressFn, 69)
	if not ok then
		alert("keypress(69) failed - auto-sell cannot press E")
		return false
	end
	task.wait(0.22)
	if type(keyReleaseFn) == "function" then pcall(keyReleaseFn, 69) end
	return true
end

-- WHERE TO STAND. The prompt on CargoVolume is a TOGGLE: it reads "Add Items"
-- while the hopper is empty and "Take Items" once ore is in it. So E must be
-- pressed exactly ONCE per dump - a second press takes the ore back out into
-- the backpack, which is what a press retry was quietly doing.
--
-- The spot is straight above the hopper. Measured: CargoVolume sits at y 4.40
-- with height 3.76; dropping the character 1 stud above its centre lands them on
-- top of the machine at y 9.6, still 5.2 studs from the prompt, no launch. Two
-- or three studs above the centre DOES launch (peak y 34 / 42) - that was the
-- fling - so the offset stays at 1. Raycasts and GetPartBoundsInBox are both
-- unavailable here, this is measured geometry.
local HOVER_ABOVE = 1

local function hoverSpot(cv)
	return Vector3.new(cv.Position.X, cv.Position.Y + HOVER_ABOVE, cv.Position.Z)
end

-- Put the character above the hopper and check it is still there. The machine
-- lifts it to the top of the volume (~4 studs up), so height is allowed to rise;
-- being moved away horizontally means the server undid the teleport.
local function standAbove(hrp, spot)
	hrp.CFrame = CFrame.new(spot.X, spot.Y, spot.Z)
	for _ = 1, 8 do
		task.wait(0.05)
		local pos = hrp.Position
		local flat = (Vector3.new(pos.X, 0, pos.Z) - Vector3.new(spot.X, 0, spot.Z)).Magnitude
		if flat > 5 then return false end
		-- the machine lifts the character to y 9.6 with a small overshoot to 12.2
		-- on some arrivals, while a real launch goes to 34-47 - +9 tells them apart
		if pos.Y > spot.Y + 9 then return false end
	end
	return true
end

-- returns true only when the backpack count actually went down
local function dumpOre()
	local _, hrp, hum = characterParts()
	if not hrp then return false end
	if hum and hum.Sit then return false end
	local cv = cargoVolume()
	if not cv then return false end
	local before = oreCount()
	if before <= 0 then return false end
	local home = hrp.Position
	local far = (home - cv.Position).Magnitude > UMT.cfg.sellRange
	local pressed = false

	-- ONE press, then only read the result. The prompt toggles between Add and
	-- Take, so pressing again would undo the deposit. The pack count is polled
	-- purely so debug mode can say whether the ore actually went in.
	local function try()
		if (hrp.Position - cv.Position).Magnitude > 12 then return false end
		if not tapE() then return false end
		for _ = 1, 6 do
			task.wait(0.15)
			if oreCount() < before then UMT.lastDumpDropped = true break end
		end
		-- Remember the pack size after EVERY press, not only a successful one.
		-- The prompt is a toggle: with ore already sitting in the hopper a press
		-- took 16 chunks straight back out (measured 1 -> 17). Until the pack
		-- grows past this number (you picked more up) the loop must not press.
		UMT.leftover = oreCount()
		return true
	end

	UMT.lastDumpDropped = false
	if far then
		if standAbove(hrp, hoverSpot(cv)) then
			pressed = try()
		else
			log("auto-sell: the teleport above the hopper was undone - nothing pressed")
		end
	else
		pressed = try()
	end

	-- always come back, pressed or not: being stranded at the hopper is worse
	-- than a wasted trip. THE RETURN IS TWO HOPS ON PURPOSE. Measured: writing
	-- the home CFrame straight from on top of the hopper is resolved as an
	-- ejection - the character went to y 25 and 18 instead of home, three
	-- writes in a row - which is the "launched upward for a second" the old
	-- builds showed. A sideways hop of 14 studs to clear ground first sticks
	-- the first time (y 5.1), and home then sticks too.
	if far and UMT.cfg.sellReturn then
		local off = home - cv.Position
		off = Vector3.new(off.X, 0, off.Z)
		if off.Magnitude < 1 then off = Vector3.new(1, 0, 0) end
		off = off.Unit
		-- walk off the machine in 3-stud CFrame hops. Measured: after the E press
		-- a single long write from on top is resolved as an ejection (y 9.6 up to
		-- 29), while 3-stud hops are accepted and settle to the floor - 9.6 ->
		-- 5.1 over four hops with no jump in height at all.
		task.wait(0.45)
		for _ = 1, 5 do
			local _, h = characterParts()
			if not h then break end
			local p = h.Position
			h.CFrame = CFrame.new(p.X + off.X * 3, p.Y, p.Z + off.Z * 3)
			task.wait(0.3)
		end
		-- then the actual trip back, read back and repeated if the server undid it
		task.wait(0.3)
		local back = home + Vector3.new(0, 0.5, 0)
		for _ = 1, 3 do
			local _, h2 = characterParts()
			if not h2 then break end
			h2.CFrame = CFrame.new(back.X, back.Y, back.Z)
			task.wait(0.4)
			local _, h3 = characterParts()
			if not h3 then break end
			if (h3.Position - home).Magnitude < 8 then break end
			log(string.format("auto-sell: return still %.1f studs off - writing again", (h3.Position - home).Magnitude))
		end
	end

	if pressed then
		UMT.sold = (UMT.sold or 0) + 1
		log(string.format("auto-sell: pressed E, backpack now %d (dropped=%s)", oreCount(), tostring(UMT.lastDumpDropped)))
	end
	return pressed
end

UMT.sellNow = dumpOre
UMT.oreCount = oreCount

-- one idle loop for the whole session; it costs a child count every 0.6s and
-- does nothing at all while the toggle is off
function UMT.sellLoop()
	-- sellRunning alone is not proof the loop is alive: if its thread was ever
	-- killed the flag stays set and auto-sell would silently never start again.
	-- task.spawn does not return a thread here, so liveness is a heartbeat.
	local now = os.clock()
	if UMT.sellRunning and UMT.sellBeat and (now - UMT.sellBeat) < 3 then return end
	UMT.sellRunning = true
	UMT.sellBeat = now
	task.spawn(function()
		while UMT.sellRunning do
			UMT.sellBeat = os.clock()
			task.wait(0.6)
			local n = oreCount()
			-- the pack went down on its own (a dump landed, or you emptied it):
			-- forget the old leftover so the next pickup can trigger again
			if UMT.leftover and n < UMT.leftover then UMT.leftover = n end
			-- "more than last time's leftover" and not merely "at least sellMin":
			-- pressing with only the leftover in the pack would TAKE the ore back
			if UMT.cfg.autoSell and n >= (UMT.cfg.sellMin or 1) and n > (UMT.leftover or 0) then
				pcall(dumpOre)
				task.wait(1.0)
			end
		end
	end)
end

--=========================== KEYBINDS =====================================
-- kept on UMT, not in a local: rerunning the script makes a new chunk, and a
-- chunk-local handle would install a second handler that nothing can unhook.
-- The throttle would hide the double teleport, the second tab would not.

-- Enum.KeyCode.X -> number, whether we were handed an EnumItem or a number
local function keyValue(kc)
	if type(kc) == "number" then return kc end
	local ok, v = pcall(function() return kc.Value end)
	if ok and type(v) == "number" then return v end
	return nil
end

local function keyCode(name)
	local ok, e = pcall(function() return Enum.KeyCode[name] end)
	if ok and e then return keyValue(e) end
	return nil
end

local function throttled()
	local now = os.clock()
	if now - UMT.lastTp < UMT.cfg.cooldownS then return true end
	UMT.lastTp = now
	return false
end

local function onKey(input)
	if UMT.gen ~= myGen then return end -- stale handler from an earlier load
	if not UMT.cfg.keys then return end
	local kc = input and input.KeyCode
	local v = keyValue(kc)
	if v == nil then return end
	local plotV, vehV = keyCode(UMT.cfg.plotKey), keyCode(UMT.cfg.vehicleKey)
	if v == plotV then
		if throttled() then return end
		goPlot()
	elseif v == vehV then
		if throttled() then return end
		goVehicle()
	end
end

local function installKeys()
	-- always replace: a rerun must hand the keys to the newest chunk, and the
	-- generation check retires anything older that we no longer hold a handle to
	if UMT.keyConn then
		pcall(function() UMT.keyConn:Disconnect() end)
		UMT.keyConn = nil
	end
	local ok, conn = pcall(function() return UIS.InputBegan:Connect(onKey) end)
	if ok and conn then
		UMT.keyConn = conn
		log("keybinds: " .. UMT.cfg.plotKey .. " = plot, " .. UMT.cfg.vehicleKey .. " = vehicle")
	else
		alert("InputBegan is not available here - use the buttons or _G.UMT.toPlot() / .toVehicle()")
	end
end

local function removeKeys()
	if UMT.keyConn then
		pcall(function() UMT.keyConn:Disconnect() end)
		UMT.keyConn = nil
		log("keybinds removed")
	end
end

--=========================== INTERFACE ====================================
-- _G.UMT.toPlot() / .toVehicle() are the console entry points; the cache keys
-- are separate so a model named "plot" can never shadow the function.
UMT.toPlot = function() return goPlot() end
UMT.toVehicle = function() return goVehicle() end
-- exposed so the handler can be rebuilt from the console (and so the throttle
-- can be proved: tpCount is what actually moved, not what was asked for)
UMT.installKeys = installKeys
UMT.removeKeys = removeKeys
UMT.tpCount = 0
-- console hook: run one key through the exact handler path. Useful when the
-- game window is unfocused, where synthetic keypress events are not delivered.
UMT.press = function(name)
	local v = keyCode(tostring(name))
	if v == nil then
		alert("unknown key: " .. tostring(name))
		return false
	end
	onKey({ KeyCode = v })
	return true
end

UMT.status = function()
	local plot, how = UMT.cache.plot, "cache"
	if not plot or not plot.Parent then plot, how = findPlot() UMT.cache.plot = plot end
	local v = UMT.cache.vehicle
	if not v or not v.Parent then v = findVehicle() UMT.cache.vehicle = v end
	local _, hrp = characterParts()
	-- always prints: the user pressed a button to see this
	alert(string.format("build %s | plot: %s (%s) | vehicle: %s | keys: %s / %s | keysOn=%s lean=%s debug=%s | ore=%d autoSell=%s | you: %s",
		UMT.build,
		plot and plot.Name or "none", tostring(how),
		v and (v.Name .. " @" .. tostring(vehicleAnchor(v))) or "none",
		UMT.cfg.plotKey, UMT.cfg.vehicleKey, tostring(UMT.cfg.keys), tostring(UMT.cfg.lean), tostring(UMT.cfg.debug),
		oreCount(), tostring(UMT.cfg.autoSell),
		hrp and tostring(hrp.Position) or "no character"))
end

UMT.refresh = function()
	UMT.cache.plot = findPlot()
	UMT.cache.vehicle = findVehicle()
	log("targets refreshed: plot=" .. (UMT.cache.plot and UMT.cache.plot.Name or "none")
		.. " vehicle=" .. (UMT.cache.vehicle and UMT.cache.vehicle.Name or "none"))
end

UMT.stop = function()
	removeKeys()
	log("stopped - buttons in the tab still work until you rerun, _G.UMT is left in place")
end

--=========================== REM UI =======================================
local function getRem()
	local ok, r = pcall(function() return Rem end)
	if ok and r and r.Alive then return r end
	return nil
end

local function loadRem()
	-- rem.lua is the live library file; anything else 404s and the HTML body
	-- would blow up loadstring, so the source is validated before it is run.
	local urls = {
		"https://raw.githubusercontent.com/9mfg/rem-ui/main/rem.lua",
	}
	for _, url in ipairs(urls) do
		local ok, src = pcall(function() return game:HttpGet(url) end)
		if ok and type(src) == "string" and #src > 200
			and not string.find(src, "^404", 1)
			and not string.find(src, "Not Found", 1, true) then
			pcall(function() loadstring(src)() end)
			local r = getRem()
			if r then return r end
		end
	end
	return nil
end

installKeys()
UMT.sellLoop()

local Rem = getRem() or loadRem()
if not (Rem and Rem.Alive) then
	log("REM UI could not be loaded (rem.lua) - keybinds are installed anyway; use _G.UMT.toPlot() / .toVehicle()")
	UMT.status()
	return UMT
end

--=========================== LEAN UI =====================================
-- REM is a Drawing-based menu: every frame it writes a few hundred Drawing
-- properties, and the three flags below are the animated ones. Measured here
-- with the menu open on your plot: 59.0 fps at the defaults, 59.3 fps lean, so
-- the menu is roughly 0.3ms of a 16.6ms frame - it is NOT what makes the GAME
-- lag. Lean is on by default because it is free; if the game still stutters
-- with the menu closed, the cost is elsewhere and this toggle will prove it.
local function applyLean(on)
	on = on and true or false
	UMT.cfg.lean = on
	if not (Rem and Rem.Alive) then return end
	Rem.Effects = not on -- glow boxes, 14 dust motes, 28-segment light trail
	Rem.PixelRem = not on -- the pixel mascot, hundreds of tiny boxes a frame
	Rem.ReducedMotion = on -- skips the easing/bob maths
	log("lean UI " .. (on and "ON - glow, dust, trail, mascot and easing are off" or "OFF - full REM effects"))
end

-- frame rate over N seconds, so a complaint about lag becomes a number
UMT.fps = function(sec)
	sec = tonumber(sec) or 2
	local n = 0
	local conn
	local ok = pcall(function() conn = RunService.RenderStepped:Connect(function() n = n + 1 end) end)
	if not ok or not conn then log("RenderStepped is not available here") return nil end
	task.wait(sec)
	pcall(function() conn:Disconnect() end)
	local f = n / sec
	log(string.format("fps %.1f over %.1fs (menu %s, lean %s)", f, sec,
		(Rem and Rem.Alive and Rem.Visible) and "open" or "closed", tostring(UMT.cfg.lean)))
	return f
end

applyLean(UMT.cfg.lean)

-- Reuse the tab if this script was already loaded: REM keeps Tabs forever,
-- so rerunning without this check leaves a second identical tab behind.
local existing = nil
for _, t in ipairs(Rem.Tabs or {}) do
	if t.Title == "Mining TP" then existing = t break end
end

-- A tab cannot gain controls or change its callbacks (REM has no remove), so a
-- tab from any other build is thrown away with the whole menu and rebuilt.
-- Destroy is the clean path: it disconnects the render connection and removes
-- every Drawing the library owns. Without this, a tab from v3 would keep a
-- "Keybinds on" toggle that writes the retired cfg.enabled flag.
if existing and UMT.tabBuild ~= UMT.build then
	log("tab is from " .. tostring(UMT.tabBuild) .. " - rebuilding the menu")
	pcall(function() Rem:Destroy() end)
	Rem = getRem() or loadRem()
	existing = nil
end

local function buildTab(tab)
-- REM shows 4 controls per page in the order they are added, so the two
-- teleports come first - they are the whole point of the script.
tab:AddButton({
	Title = "Teleport to my plot",
	Description = "Finds your plot from your own factory grid and drops you on its BuildPlot. Keybind " .. UMT.cfg.plotKey .. " by default.",
	ButtonText = "Go",
	Callback = function()
		if goPlot() then
			pcall(function() Rem:Notify("Mining TP", "On your plot.", 3) end)
		else
			pcall(function() Rem:Notify("Mining TP", "Plot not found - see the console.", 4) end)
		end
	end,
})

tab:AddButton({
	Title = "Teleport to my vehicle",
	Description = "Matches workspace.Vehicles by OwnerId, so it finds YOUR vehicle and not the two other players' ones in the same folder.",
	ButtonText = "Go",
	Callback = function()
		if goVehicle() then
			pcall(function() Rem:Notify("Mining TP", "At your vehicle.", 3) end)
		else
			pcall(function() Rem:Notify("Mining TP", "Vehicle not found - see the console.", 4) end)
		end
	end,
})

tab:AddDropdown({
	Title = "Plot key",
	Description = "The key that teleports you to your plot.",
	Options = { "P", "F", "G", "H", "J", "K", "B", "N", "M", "V" },
	Default = UMT.cfg.plotKey,
	Callback = function(v)
		UMT.cfg.plotKey = tostring(v)
		log("plot key is now " .. UMT.cfg.plotKey)
	end,
})

tab:AddDropdown({
	Title = "Vehicle key",
	Description = "The key that teleports you to your vehicle.",
	Options = { "V", "P", "F", "G", "H", "J", "K", "B", "N", "M" },
	Default = UMT.cfg.vehicleKey,
	Callback = function(v)
		UMT.cfg.vehicleKey = tostring(v)
		log("vehicle key is now " .. UMT.cfg.vehicleKey)
	end,
})

-- page 2
tab:AddToggle({
	Title = "Keybinds on",
	Description = "Off leaves the two buttons working; only the keys stop.",
	Default = UMT.cfg.keys,
	Callback = function(v)
		UMT.cfg.keys = v and true or false
		log("keybinds " .. (UMT.cfg.keys and "ON" or "OFF"))
	end,
})

tab:AddToggle({
	Title = "Lean UI",
	Description = "Drops REM's glow, dust, light trail, pixel mascot and easing. On by default; off restores the full look.",
	Default = UMT.cfg.lean,
	Callback = function(v) applyLean(v) end,
})

tab:AddToggle({
	Title = "Debug log",
	Description = "Off by default: successful teleports print nothing. On prints every jump, target and key change. Failures and the Status button always print.",
	Default = UMT.cfg.debug,
	Callback = function(v) UMT.setDebug(v) end,
})

tab:AddToggle({
	Title = "Auto-sell backpack",
	Description = "When OrePackCargo holds ore, walks the unloader prompt for you: teleports in range, presses E, and comes back. Off by default.",
	Default = UMT.cfg.autoSell,
	Callback = function(v)
		UMT.cfg.autoSell = v and true or false
		log("auto-sell " .. (UMT.cfg.autoSell and "ON" or "OFF"))
		if UMT.cfg.autoSell then UMT.sellLoop() end
	end,
})

-- REM's AddSlider ignores Default and starts at Max, and it calls the callback
-- once while building, so the real value is restored right after creation.
local wantMin = UMT.cfg.sellMin or 1
local minSlider = tab:AddSlider({
	Title = "Sell at N items",
	Description = "How many chunks in the backpack trigger a dump. 1 means as soon as you pick anything up.",
	Min = 1,
	Max = 60,
	Step = 1,
	Default = wantMin,
	Callback = function(v)
		UMT.cfg.sellMin = math.max(1, math.floor(tonumber(v) or 1))
		log("sell threshold is " .. UMT.cfg.sellMin)
	end,
})
-- SetValue is REM's own setter (silent = no callback), so the stored value and
-- the drawn slider agree instead of the slider sitting at Max
UMT.cfg.sellMin = wantMin
pcall(function() minSlider:SetValue(wantMin, true) end)

tab:AddToggle({
	Title = "Return after selling",
	Description = "Puts you back where you were standing after the dump. Off leaves you at the unloader.",
	Default = UMT.cfg.sellReturn,
	Callback = function(v)
		UMT.cfg.sellReturn = v and true or false
		log("return after selling " .. (UMT.cfg.sellReturn and "ON" or "OFF"))
	end,
})

tab:AddButton({
	Title = "Refresh targets",
	Description = "Re-reads your plot and vehicle. Use it after you unlock a new vehicle or the base finishes loading.",
	ButtonText = "Refresh",
	Callback = function() UMT.refresh() end,
})

tab:AddButton({
	Title = "Status",
	Description = "Prints the detected plot, vehicle, keys and your position to the console (F9).",
	ButtonText = "Print",
	Callback = function() UMT.status() end,
})

tab:AddButton({
	Title = "Measure FPS",
	Description = "Samples the frame rate for two seconds and prints it with the menu state. Use it to prove where lag comes from.",
	ButtonText = "2s",
	Callback = function()
		local f = UMT.fps(2)
		if f then pcall(function() Rem:Notify("Mining TP", string.format("%.1f fps (menu %s)", f, Rem.Visible and "open" or "closed"), 3) end) end
	end,
})

tab:AddButton({
	Title = "Remove keybinds",
	Description = "Unhooks the key handler. Rerun the script to get it back.",
	ButtonText = "Unhook",
	Callback = function() UMT.stop() end,
})
end -- buildTab

if existing then
	log("tab already present - reused it instead of adding a duplicate")
else
	buildTab(Rem:AddTab({ Title = "Mining TP", Icon = "script" }))
end
UMT.tabBuild = UMT.build

log("build " .. UMT.build)
log("ready: " .. UMT.cfg.plotKey .. " = my plot, " .. UMT.cfg.vehicleKey .. " = my vehicle. Right Shift opens the menu.")
if UMT.cfg.debug then UMT.status() end
return UMT
